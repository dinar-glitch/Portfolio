# Dinar Verse — Personal Portfolio

A responsive, single-page portfolio starter built with vanilla HTML, CSS, and JavaScript. Designed around an editorial/minimalist premium style, cream and antique-gold palette, a custom abstract brain illustration, scroll reveals, loading intro, custom desktop cursor, theme toggle, and mobile navigation.

## Preview locally

1. Extract the project folder.
2. Open `index.html` in a modern browser.
3. For best results, use a local static server (optional), such as VS Code's Live Server extension.

## Publish with GitHub Pages

1. Create a public repository named `YOUR-USERNAME.github.io` (replace with your exact GitHub username).
2. Upload `index.html`, `styles.css`, `script.js`, and this README to the repository root.
3. In the repository, go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/(root)`, then save.
5. Wait for GitHub Pages to publish the site at `https://YOUR-USERNAME.github.io`.

## Before going live

Replace these placeholders in `index.html`:

- `hello@example.com` with your professional email.
- Social links with your actual LinkedIn, Instagram, GitHub, and WhatsApp links.
- Certification placeholders with verified certificate names, issuers, and dates.
- Draft journal titles with finished posts or remove the section until ready.
- Concept projects with your real work when available. Current project tiles are explicitly labelled as concepts and make no client-result claims.
- Update the short bio to match your exact experience and services.

Add your professional portrait when ready. The first build uses an original SVG brain illustration as the hero visual, so it does not depend on a stock image.

## Notes

- No framework or build process is required.
- Google Fonts are loaded remotely; if you want a completely offline version, replace them with system fonts or host licensed font files locally.
- GitHub Pages serves static files. Server-side features and private form handling need an external service or backend.
- Respect `prefers-reduced-motion`; the site includes a reduced-motion fallback.
